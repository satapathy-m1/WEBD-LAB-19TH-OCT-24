// Reverse a string

/*
let  str = "Mrutyunjaya";
let reverseStr = (str) => {
    let i = 0;
    let j = str.length-1;
    while(i <= j)
    {
        let temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }

    return str;
}

console.log(reverseStr());
*/
function reverseString(str) {
    let reversed = '';
    let leftIndex = 0;
    let rightIndex = str.length - 1;

    for(let i  = rightIndex; i>= 0; i--)
    {
        reversed += str[i];
    }

    return reversed;
}


const originalString = "Mrutyunjaya";
console.log("O G string ", originalString);
const reversedString = reverseString(originalString);
console.log("After reversing", reversedString);
