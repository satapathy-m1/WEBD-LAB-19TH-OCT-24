function isPalindrome(s)
{
    let i = 0;
    let j = s.length-1;
    while(i <= j)
    {
        if(s[i] != s[j]) return false;
        else {
            i++;
            j--;
        } 
    }
    return true;
}


let s = "racecar";
console.log("The given string is ", s);
console.log("Is the given string a palindrome?:- ", isPalindrome(s));