function isPrime(number)
{
    let cnt = 0;
    for(let i = 1; i <= number; i++)
    {
        if(number % i == 0) cnt++;
    }
    return cnt <= 2;
}


let number = 97;
console.log("is ",number, "a prime no? " , isPrime(number));