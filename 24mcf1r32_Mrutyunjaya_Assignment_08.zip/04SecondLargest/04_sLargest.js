let arr1 = [5, 4, 2, 6, 4, 8, 90, 56];

let second = -1;
let first = -1;

for(let i = 0; i < arr1.length; i++)
{
    let ele = arr1[i];
    if(ele > first)
    {
        second = first;
        first = ele;
    }
    else if(ele < first && ele >= second) second = ele;
}
console.log("The second largest element is:- ", second);