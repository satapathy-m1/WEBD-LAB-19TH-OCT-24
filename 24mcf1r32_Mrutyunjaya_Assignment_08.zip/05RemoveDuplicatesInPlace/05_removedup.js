function removeDuplicatesInPlace(arr)
{
    let cnt = 0;
    for(let i = 0; i < arr.length; i++)
    {
        if(i === 0 || arr[i] != arr[i - 1])
        {
            arr[cnt++] = arr[i];
        }
    }
    return cnt;
}

let arr1 = [1, 1, 1, 2, 3, 3, 3, 4, 5, 6, 6, 6, 7, 7, 8];
let length = removeDuplicatesInPlace(arr1);
// console.log(length, arr1);
console.log(length, arr1.slice(0, length));