function firstOcc(arr, number)
{
    let low = 0;
    let high = arr.length - 1;
    let ans = -1;
    while(low <= high)
    {
        let mid =Math.floor( low + (high - low)/2);
        if(arr[mid] === number)
        {
            ans = mid;
            high = mid - 1;
        }
        else if(arr[mid] < number) low = mid + 1;
        else high = mid - 1;
    }
    return ans;
}


let arr = [1, 2, 2, 2, 3, 4];
let target = 2;
console.log("First occurence of ", target, " is at index ", firstOcc(arr, target));